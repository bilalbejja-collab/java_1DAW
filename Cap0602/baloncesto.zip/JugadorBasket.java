/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baloncestoapp;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author franmatias
 */
public class JugadorBasket implements Serializable {

    public enum Posicion {
        BASE("B"), ESCOLTA("E"), PIVOT("P"), ALERO("A"), ALAPIVOT("F");
        String posicion;
        Posicion(String posicion){
            this.posicion = posicion;
        }
        public void setPosicion(String posicion){
        
        }
    }

    private int dorsal;
    private String nombre;
    private String equipo;
    private Posicion posicion;
    private double altura;
    private LocalDate fechaNacimiento;
    private int minutosJugados;
    private int totalPuntos;
    private int tiros2P;
    private int triples;

    public JugadorBasket(int dorsal, String nombre, String equipo, Posicion posicion, double altura, LocalDate fechaNacimiento, int minutosJugados, int totalPuntos, int tiros2P, int triples) {
        this.dorsal = dorsal;
        this.nombre = nombre;
        this.equipo = equipo;
        this.posicion = posicion;
        this.altura = altura;
        this.fechaNacimiento = fechaNacimiento;
        this.minutosJugados = minutosJugados;
        this.totalPuntos = totalPuntos;
        this.tiros2P = tiros2P;
        this.triples = triples;
    }

    /**
     * @return the dorsal
     */
    public int getDorsal() {
        return dorsal;
    }

    /**
     * @param dorsal the dorsal to set
     */
    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the equipo
     */
    public String getEquipo() {
        return equipo;
    }

    /**
     * @param equipo the equipo to set
     */
    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    /**
     * @return the posicion
     */
    public Posicion getPosicion() {
        return posicion;
    }

    /**
     * @param posicion the posicion to set
     */
    public void setPosicion(Posicion posicion) {
        this.posicion = posicion;
    }

    /**
     * @return the altura
     */
    public double getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * @return the fechaNacimiento
     */
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * @param fechaNacimiento the fechaNacimiento to set
     */
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * @return the minutosJugados
     */
    public int getMinutosJugados() {
        return minutosJugados;
    }

    /**
     * @param minutosJugados the minutosJugados to set
     */
    public void setMinutosJugados(int minutosJugados) {
        this.minutosJugados = minutosJugados;
    }

    /**
     * @return the totalPuntos
     */
    public int getTotalPuntos() {
        return totalPuntos;
    }

    /**
     * @param totalPuntos the totalPuntos to set
     */
    public void setTotalPuntos(int totalPuntos) {
        this.totalPuntos = totalPuntos;
    }

    /**
     * @return the tiros2P
     */
    public int getTiros2P() {
        return tiros2P;
    }

    /**
     * @param tiros2P the tiros2P to set
     */
    public void setTiros2P(int tiros2P) {
        this.tiros2P = tiros2P;
    }

    /**
     * @return the triples
     */
    public int getTriples() {
        return triples;
    }

    /**
     * @param triples the triples to set
     */
    public void setTriples(int triples) {
        this.triples = triples;
    }

}
